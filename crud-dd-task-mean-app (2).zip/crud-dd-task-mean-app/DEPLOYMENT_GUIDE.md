# MEAN Stack CRUD Application - DevOps Deployment Guide

This guide provides comprehensive instructions for deploying the MEAN (MongoDB, Express, Angular, Node.js) stack CRUD application using Docker, Docker Compose, and CI/CD pipelines.

## Project Overview

This is a full-stack tutorial management application with:
- **Backend**: Node.js + Express REST API
- **Frontend**: Angular 15 SPA
- **Database**: MongoDB
- **Containerization**: Docker & Docker Compose
- **CI/CD**: GitHub Actions
- **Reverse Proxy**: Nginx

## Prerequisites

### For Local Development
- Docker & Docker Compose installed
- Node.js 18+ (for local testing)
- Git

### For VM Deployment
- Ubuntu 20.04+ VM on AWS, Azure, or similar cloud provider
- Docker & Docker Compose installed
- Git
- SSH access to the VM

---

## Part 1: Repository Setup

### Step 1: Create GitHub Repository

1. Go to [GitHub](https://github.com) and create a new repository named `dd-mean-app`
2. Initialize with README (optional)
3. Clone the repository locally

### Step 2: Push Code to Repository

```bash
# Navigate to project directory
cd crud-dd-task-mean-app

# Initialize git if not already initialized
git init
git add .
git commit -m "Initial commit: MEAN stack CRUD application with Docker setup"

# Add remote and push
git remote add origin https://github.com/Shreyas-15777/dd-mean-app.git
git branch -M main
git push -u origin main
```

---

## Part 2: Local Development & Testing

### Step 1: Build Images Locally

```bash
# From project root directory
docker-compose build
```

### Step 2: Start Services

```bash
docker-compose up -d
```

### Step 3: Verify Services Are Running

```bash
# Check container status
docker-compose ps

# Expected output:
# NAME         STATUS              PORTS
# dd-mongodb   Up (healthy)        27017->27017/tcp
# dd-backend   Up (healthy)        8080->8080/tcp
# dd-frontend  Up (healthy)        3000->80/tcp
# dd-nginx     Up (healthy)        80->80/tcp
```

### Step 4: Test the Application

```bash
# Check frontend health
curl http://localhost/health

# Check backend health
curl http://localhost:8080/

# Access the application
# Open browser and navigate to: http://localhost
```

### Step 5: Stop Services

```bash
docker-compose down -v  # -v removes volumes
```

---

## Part 3: Push Docker Images to Docker Hub

### Step 1: Create Docker Hub Account

1. Sign up at [Docker Hub](https://hub.docker.com)
2. Create a repository named `dd-backend`
3. Create a repository named `dd-frontend`

### Step 2: Login to Docker Hub

```bash
docker login
# Enter your Docker Hub username and password
```

### Step 3: Build and Push Images

```bash
# Backend
docker build -t Shreyas-15777/dd-backend:latest ./backend
docker push Shreyas-15777/dd-backend:latest

# Frontend
docker build -t Shreyas-15777/dd-frontend:latest ./frontend
docker push Shreyas-15777/dd-frontend:latest
```

### Step 4: Update Docker Compose File

Update the `docker-compose.yml` file to use your Docker Hub images (optional for local testing):

```yaml
services:
  backend:
    image: Shreyas-15777/dd-backend:latest
    # ... rest of config
  
  frontend:
    image: Shreyas-15777/dd-frontend:latest
    # ... rest of config
```

---

## Part 4: Setup Ubuntu VM on Cloud Provider

### Option A: AWS EC2 Setup

```bash
# 1. Launch Ubuntu 20.04 LTS instance
#    - Instance type: t2.medium or larger
#    - Storage: 30GB
#    - Security group: Allow ports 22, 80, 443

# 2. Connect to instance
ssh -i your-key.pem ubuntu@your-instance-ip

# 3. Update system
sudo apt update && sudo apt upgrade -y

# 4. Install Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# 5. Add ubuntu user to docker group
sudo usermod -aG docker ubuntu

# 6. Install Docker Compose
sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose

# 7. Verify installations
docker --version
docker-compose --version
```

### Option B: Azure VM Setup

```bash
# Similar steps as AWS, but in Azure portal:
# 1. Create Ubuntu 20.04 LTS VM
# 2. Configure inbound rules for ports 22, 80, 443
# 3. Connect via SSH and follow steps 3-7 from AWS setup
```

---

## Part 5: Deploy Application on VM

### Step 1: Clone Repository on VM

```bash
cd /home/ubuntu
git clone https://github.com/Shreyas-15777/dd-mean-app.git dd-app
cd dd-app
```

### Step 2: Update MongoDB Connection String (if needed)

Edit `backend/app/config/db.config.js` if using MongoDB Atlas:

```javascript
module.exports = {
  url: "mongodb+srv://username:password@cluster.mongodb.net/dd_db"
};
```

### Step 3: Create Environment Variables File

Create `.env` file in project root:

```bash
NODE_ENV=production
MONGODB_URL=mongodb://mongodb:27017/dd_db
DOCKER_HUB_USERNAME=shreyas1508
```

### Step 4: Pull Latest Images and Deploy

```bash
# Login to Docker Hub
docker login

# Pull latest images
docker-compose pull

# Start services
docker-compose up -d

# Verify deployment
docker-compose ps
curl http://localhost/health
curl http://localhost:8080/
```

### Step 5: Configure Auto-restart

```bash
# Edit Docker daemon config to restart on boot
sudo nano /etc/docker/daemon.json
```

Add or modify to include:
```json
{
  "live-restore": true
}
```

Then restart Docker:
```bash
sudo systemctl restart docker
```

---

## Part 6: Setup CI/CD Pipeline with GitHub Actions

### Step 1: Configure GitHub Secrets

Navigate to your GitHub repository → Settings → Secrets and variables → Actions

Add the following secrets:

1. **DOCKER_HUB_USERNAME**: Your Docker Hub username
2. **DOCKER_HUB_TOKEN**: Your Docker Hub access token (create in Docker Hub account settings)
3. **VM_HOST**: Your VM's public IP address
4. **VM_USER**: SSH username (usually `ubuntu`)
5. **VM_PRIVATE_KEY**: Your SSH private key content (paste entire key)
6. **SLACK_WEBHOOK** (optional): For Slack notifications

### Step 2: Generate Docker Hub Token

1. Go to Docker Hub → Account Settings → Security
2. Click "New Access Token"
3. Name it something like `github-actions`
4. Copy the token

### Step 3: Generate SSH Keys for VM

On your local machine:

```bash
ssh-keygen -t rsa -b 4096 -f github-actions-key -N ""

# Add public key to VM
cat github-actions-key.pub | ssh -i your-vm-key.pem ubuntu@your-instance-ip "cat >> ~/.ssh/authorized_keys"

# Copy private key content to GitHub secret
cat github-actions-key
```

### Step 4: Verify Workflow

The `.github/workflows/deploy.yml` file is already in the repository. It will:

1. Build Docker images when you push to `main` or `develop` branches
2. Push images to Docker Hub
3. Deploy to your VM (on `main` branch pushes only)
4. Run health checks
5. Send Slack notifications (if configured)

### Step 5: Trigger Deployment

```bash
# Make a change and push
git add .
git commit -m "Test deployment"
git push origin main

# Watch the GitHub Actions workflow
# Go to GitHub repo → Actions tab
```

---

## Part 7: Nginx Reverse Proxy Configuration

The application uses Nginx as a reverse proxy to:
- Route `/api/*` requests to the backend (port 8080)
- Route all other requests to the frontend (port 3000)
- Provide SSL termination (can be configured)
- Handle CORS headers
- Serve static assets with caching

### Key Configuration Details

- **Frontend**: Served from port 80 (root path `/`)
- **Backend API**: Accessed via `/api/` endpoint
- **Health Check**: Available at `/health`

### Configuration File Locations

- Main Nginx config: `./nginx.conf` (for reverse proxy)
- Frontend Nginx config: `./frontend/nginx.conf` (for Angular app)

---

## Troubleshooting

### Issue: Containers not connecting to MongoDB

```bash
# Check MongoDB logs
docker logs dd-mongodb

# Verify network connectivity
docker network inspect mean-network

# Restart services
docker-compose restart
```

### Issue: Frontend can't reach backend

1. Check backend is running: `curl http://localhost:8080/`
2. Verify API endpoint in Angular service: `src/app/services/tutorial.service.ts`
3. Check CORS headers in backend

### Issue: Port 80 already in use

```bash
# Find process using port 80
sudo lsof -i :80

# Kill the process or change port in docker-compose.yml
```

### Issue: Database persistence lost after restart

```bash
# Check volume status
docker volume ls

# Backup data if needed
docker exec dd-mongodb mongodump --out=/data/backup/
```

### View Logs

```bash
# All services
docker-compose logs -f

# Specific service
docker-compose logs -f backend
docker-compose logs -f frontend
docker-compose logs -f mongodb

# Clear old logs
docker-compose logs --tail 100 backend
```

---

## Monitoring & Maintenance

### Check Service Status

```bash
docker-compose ps

# More detailed info
docker-compose ps -a
docker stats
```

### Update Application

```bash
cd /home/ubuntu/dd-app
git pull origin main
docker-compose down
docker-compose build
docker-compose up -d
```

### Database Backup

```bash
# MongoDB backup
docker exec dd-mongodb mongodump --out=/data/backup/

# Copy from container
docker cp dd-mongodb:/data/backup ./backup
```

### Database Restore

```bash
docker cp ./backup dd-mongodb:/data/
docker exec dd-mongodb mongorestore /data/backup
```

---

## Security Best Practices

1. **SSH Keys**: Use SSH keys instead of passwords
2. **Firewalls**: Only open necessary ports (22 for SSH, 80 for HTTP)
3. **Updates**: Keep Docker and OS packages updated
4. **Secrets**: Never commit `.env` files or sensitive data
5. **Database**: Use strong MongoDB credentials for production
6. **HTTPS**: Consider adding SSL certificates with Let's Encrypt
7. **Non-root**: Containers run as non-root users by default

---

## Performance Optimization

1. **Image Optimization**: Use Alpine Linux for smaller images
2. **Caching**: Docker layer caching for faster builds
3. **Volume Management**: Use named volumes for data persistence
4. **Resource Limits**: Configure memory and CPU limits in docker-compose.yml
5. **Gzip Compression**: Enabled in Nginx for static assets
6. **Asset Caching**: Long cache headers for static assets

---

## Additional Resources

- [Docker Documentation](https://docs.docker.com/)
- [Docker Compose Documentation](https://docs.docker.com/compose/)
- [GitHub Actions Documentation](https://docs.github.com/en/actions)
- [Nginx Documentation](https://nginx.org/en/docs/)
- [MongoDB Docker Hub](https://hub.docker.com/_/mongo)

---

## Support & Questions

For issues or questions:
1. Check the Troubleshooting section above
2. Review Docker and application logs
3. Verify all services are running: `docker-compose ps`
4. Check GitHub Actions workflow for deployment errors

---

## Project Structure

```
crud-dd-task-mean-app/
├── backend/
│   ├── app/
│   │   ├── config/
│   │   ├── controllers/
│   │   ├── models/
│   │   └── routes/
│   ├── Dockerfile
│   ├── package.json
│   └── server.js
├── frontend/
│   ├── src/
│   ├── Dockerfile
│   ├── nginx.conf
│   ├── package.json
│   └── angular.json
├── .github/
│   └── workflows/
│       └── deploy.yml
├── docker-compose.yml
├── nginx.conf
├── README.md
└── DEPLOYMENT_GUIDE.md (this file)
```

---

**Last Updated**: February 2026
**Version**: 1.0
