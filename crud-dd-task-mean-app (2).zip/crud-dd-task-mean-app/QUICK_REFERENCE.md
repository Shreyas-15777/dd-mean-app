# Quick Reference Guide

## Local Development

### Quick Start
```bash
# Clone and setup
git clone <your-repo-url>
cd crud-dd-task-mean-app
./setup.sh

# Or manual setup
docker-compose build
docker-compose up -d
```

### Common Commands

#### Check Status
```bash
docker-compose ps                    # View all services
docker-compose logs -f               # View real-time logs
docker-compose logs backend          # View specific service logs
docker stats                         # View resource usage
```

#### Stop/Start Services
```bash
docker-compose stop                  # Stop services (data preserved)
docker-compose start                 # Start stopped services
docker-compose restart               # Restart services
docker-compose down                  # Stop and remove containers
docker-compose down -v               # Stop and remove volumes (data lost)
```

#### View Data
```bash
# Access MongoDB shell
docker exec -it dd-mongodb mongosh

# List databases
show dbs

# Use database
use dd_db

# View collections
show collections

# View documents
db.tutorials.find()
```

#### Rebuild
```bash
docker-compose build                 # Rebuild all images
docker-compose build backend         # Rebuild specific service
docker-compose build --no-cache      # Rebuild without cache
```

#### Testing
```bash
# Test backend API
curl http://localhost:8080/
curl -X GET http://localhost:8080/api/tutorials
curl -X POST http://localhost:8080/api/tutorials \
  -H "Content-Type: application/json" \
  -d '{"title":"Test","description":"Test tutorial"}'

# Test frontend
curl http://localhost/health
curl http://localhost/

# Test reverse proxy
curl http://localhost/api/tutorials
```

---

## Deployment on VM

### Initial Setup
```bash
# SSH to VM
ssh -i your-key.pem ubuntu@your-vm-ip

# Run deployment script
curl -O https://raw.githubusercontent.com/Shreyas-15777/dd-mean-app/main/deploy-vm.sh
chmod +x deploy-vm.sh
./deploy-vm.sh

# Or manual setup
curl -fsSL https://get.docker.com | sh
sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose
git clone <your-repo-url> dd-app
cd dd-app
docker-compose up -d
```

### Update Application
```bash
cd /home/ubuntu/dd-app
git pull origin main
docker-compose pull
docker-compose down
docker-compose up -d
```

### View Logs on VM
```bash
cd /home/ubuntu/dd-app
docker-compose logs -f                # All services
docker-compose logs -f backend        # Backend only
docker-compose logs -f frontend       # Frontend only
docker-compose logs -f mongodb        # MongoDB only
tail -f cron.log                      # Cron job logs
```

### Database Backup/Restore
```bash
# Backup
docker exec dd-mongodb mongodump --out=/data/backup/
docker cp dd-mongodb:/data/backup ./backup

# Restore
docker cp ./backup dd-mongodb:/data/
docker exec dd-mongodb mongorestore /data/backup
```

---

## GitHub Actions Setup

### Required Secrets
In GitHub repo → Settings → Secrets and variables → Actions:

1. **DOCKER_HUB_USERNAME** - Your Docker Hub username
2. **DOCKER_HUB_TOKEN** - Docker Hub access token
3. **VM_HOST** - VM's public IP or hostname
4. **VM_USER** - SSH username (usually `ubuntu`)
5. **VM_PRIVATE_KEY** - SSH private key content

### Trigger Deployment
```bash
# Push to main branch triggers deployment
git push origin main

# View workflow in GitHub Actions tab
# Monitor deployment at: repo → Actions → Latest workflow
```

---

## Troubleshooting

### Services Not Starting
```bash
# Check logs
docker-compose logs

# Restart all services
docker-compose down -v
docker-compose up -d

# Check port conflicts
sudo lsof -i :80
sudo lsof -i :8080
sudo lsof -i :27017
```

### MongoDB Connection Issues
```bash
# Check MongoDB health
docker-compose ps mongodb
docker logs dd-mongodb

# Restart MongoDB
docker-compose restart mongodb

# Verify connection from backend
docker-compose exec backend curl http://mongodb:27017
```

### Frontend Not Accessible
```bash
# Check frontend logs
docker-compose logs frontend

# Verify Nginx config
docker exec dd-nginx nginx -t

# Test Nginx
curl http://localhost/health

# Restart frontend
docker-compose restart frontend
```

### API Calls Failing
```bash
# Check backend
curl http://localhost:8080/
curl http://localhost:8080/api/tutorials

# Check logs
docker-compose logs backend

# Verify MongoDB connection
docker-compose logs backend | grep "Connected to the database"
```

### High Memory Usage
```bash
# Check resource usage
docker stats

# Limit memory in docker-compose.yml
# Add under service:
#   deploy:
#     resources:
#       limits:
#         memory: 512M

# Rebuild and restart
docker-compose down
docker-compose up -d
```

---

## Performance Tips

1. **Cache Layers**: Docker caches build layers - change frequently modified files last
2. **Volume Mounting**: Use named volumes for persistence instead of bind mounts
3. **Image Size**: Use Alpine Linux base images (much smaller)
4. **Multi-stage Builds**: Dockerfile uses multi-stage to reduce final image size
5. **Compression**: Nginx gzip enabled for static assets
6. **Caching**: Static assets cached for 30 days in browser

---

## Security Checklist

- [ ] Change default passwords if any
- [ ] Keep Docker images updated
- [ ] Use SSH keys instead of passwords
- [ ] Only open necessary ports
- [ ] Use environment variables for secrets (not in code)
- [ ] Enable firewall rules
- [ ] Regular backups of database
- [ ] Monitor logs for suspicious activity
- [ ] Update system packages regularly
- [ ] Use HTTPS in production (with SSL certificates)

---

## Useful Links

- [Docker Docs](https://docs.docker.com)
- [Docker Compose Docs](https://docs.docker.com/compose)
- [GitHub Actions Docs](https://docs.github.com/en/actions)
- [MongoDB Docker Hub](https://hub.docker.com/_/mongo)
- [Nginx Docs](https://nginx.org/en/docs)
- [Angular Docs](https://angular.io/docs)

---

## File Locations

```
Project Root/
├── backend/
│   ├── Dockerfile              # Backend Docker image
│   ├── .dockerignore
│   ├── app/
│   │   ├── config/db.config.js # MongoDB connection
│   │   ├── controllers/
│   │   ├── models/
│   │   └── routes/
│   ├── package.json
│   └── server.js
├── frontend/
│   ├── Dockerfile              # Frontend Docker image
│   ├── .dockerignore
│   ├── nginx.conf              # Frontend Nginx config
│   ├── src/
│   │   ├── app/
│   │   │   └── services/tutorial.service.ts
│   │   └── environments/
│   ├── package.json
│   └── angular.json
├── .github/
│   └── workflows/deploy.yml    # CI/CD Pipeline
├── docker-compose.yml          # Main Docker Compose file
├── nginx.conf                  # Reverse proxy Nginx config
├── setup.sh                    # Quick setup script
├── deploy-vm.sh                # VM deployment script
├── DEPLOYMENT_GUIDE.md         # Full deployment guide
├── README.md                   # Project README
└── .gitignore
```

---

## Environment Variables

### Backend (.env)
```
NODE_ENV=production
PORT=8080
MONGODB_URL=mongodb://mongodb:27017/dd_db
```

### Docker Compose
- All services run in `mean-network` network
- MongoDB: `mongodb://mongodb:27017/dd_db`
- Backend: `http://backend:8080`
- Frontend: `http://frontend:80`

---

## Common Issues & Solutions

| Issue | Solution |
|-------|----------|
| Port 80 already in use | Change port in docker-compose.yml or kill using process |
| Can't connect to MongoDB | Restart services: `docker-compose restart mongodb` |
| Frontend not loading | Check Nginx config: `docker exec dd-nginx nginx -t` |
| API calls failing | Verify backend: `curl http://localhost:8080/` |
| Out of disk space | Clean images: `docker system prune -a` |
| Memory issues | Limit resources in docker-compose.yml |
| Volumes not persisting | Check volume mount in docker-compose.yml |

---

**Last Updated**: February 2026
