#!/bin/bash

# MEAN Stack CRUD Application - VM Deployment Script
# Run this script on your Ubuntu VM after SSH connection

set -e

# Colors for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${BLUE}=========================================="
echo "MEAN Stack CRUD App - VM Deployment"
echo "==========================================${NC}"

# Check if running as ubuntu user
if [ "$USER" != "ubuntu" ]; then
    echo -e "${RED}This script should be run as 'ubuntu' user${NC}"
    exit 1
fi

# Update system
echo -e "\n${BLUE}Step 1: Updating system packages...${NC}"
sudo apt update
sudo apt upgrade -y
echo -e "${GREEN}✓ System updated${NC}"

# Install Docker
echo -e "\n${BLUE}Step 2: Installing Docker...${NC}"
if command -v docker &> /dev/null; then
    echo -e "${GREEN}✓ Docker already installed${NC}"
else
    curl -fsSL https://get.docker.com -o get-docker.sh
    sudo sh get-docker.sh
    rm get-docker.sh
    echo -e "${GREEN}✓ Docker installed${NC}"
fi

# Add user to docker group
echo -e "\n${BLUE}Step 3: Adding user to docker group...${NC}"
sudo usermod -aG docker ubuntu
echo -e "${GREEN}✓ User added to docker group${NC}"
echo -e "${YELLOW}Note: You may need to log out and log back in for group changes to take effect${NC}"

# Install Docker Compose
echo -e "\n${BLUE}Step 4: Installing Docker Compose...${NC}"
if command -v docker-compose &> /dev/null; then
    echo -e "${GREEN}✓ Docker Compose already installed${NC}"
else
    COMPOSE_VERSION=$(curl -s https://api.github.com/repos/docker/compose/releases/latest | grep 'tag_name' | cut -d'"' -f4)
    sudo curl -L "https://github.com/docker/compose/releases/download/${COMPOSE_VERSION}/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
    sudo chmod +x /usr/local/bin/docker-compose
    echo -e "${GREEN}✓ Docker Compose installed${NC}"
fi

# Install Git
echo -e "\n${BLUE}Step 5: Installing Git...${NC}"
if command -v git &> /dev/null; then
    echo -e "${GREEN}✓ Git already installed${NC}"
else
    sudo apt install -y git
    echo -e "${GREEN}✓ Git installed${NC}"
fi

# Install curl
echo -e "\n${BLUE}Step 6: Installing curl...${NC}"
if command -v curl &> /dev/null; then
    echo -e "${GREEN}✓ curl already installed${NC}"
else
    sudo apt install -y curl
    echo -e "${GREEN}✓ curl installed${NC}"
fi

# Verify installations
echo -e "\n${BLUE}Step 7: Verifying installations...${NC}"
echo "Docker version:"
docker --version
echo "Docker Compose version:"
docker-compose --version
echo "Git version:"
git --version
echo -e "${GREEN}✓ All tools verified${NC}"

# Clone repository
echo -e "\n${BLUE}Step 8: Cloning repository...${NC}"
if [ ! -d "/home/ubuntu/dd-app" ]; then
    echo "Enter your GitHub repository URL:"
    read REPO_URL
    
    cd /home/ubuntu
    git clone "$REPO_URL" dd-app
    cd dd-app
    echo -e "${GREEN}✓ Repository cloned${NC}"
else
    echo -e "${YELLOW}dd-app directory already exists. Updating...${NC}"
    cd /home/ubuntu/dd-app
    git pull origin main
    echo -e "${GREEN}✓ Repository updated${NC}"
fi

# Configure Docker daemon for restart
echo -e "\n${BLUE}Step 9: Configuring Docker for auto-restart...${NC}"
sudo mkdir -p /etc/docker
sudo bash -c 'cat > /etc/docker/daemon.json' << 'EOF'
{
  "live-restore": true,
  "log-driver": "json-file",
  "log-opts": {
    "max-size": "10m",
    "max-file": "3"
  }
}
EOF
sudo systemctl restart docker
echo -e "${GREEN}✓ Docker configured${NC}"

# Create .env file if it doesn't exist
echo -e "\n${BLUE}Step 10: Setting up environment...${NC}"
if [ ! -f "/home/ubuntu/dd-app/.env" ]; then
    cat > /home/ubuntu/dd-app/.env << 'EOF'
NODE_ENV=production
MONGODB_URL=mongodb://mongodb:27017/dd_db
PORT=8080
EOF
    echo -e "${GREEN}✓ .env file created${NC}"
else
    echo -e "${GREEN}✓ .env file already exists${NC}"
fi

# Build and start services
echo -e "\n${BLUE}Step 11: Building and starting services...${NC}"
cd /home/ubuntu/dd-app
docker-compose build
docker-compose up -d
echo -e "${GREEN}✓ Services started${NC}"

# Wait for services to be healthy
echo -e "\n${BLUE}Waiting for services to be healthy...${NC}"
sleep 15

# Check status
echo -e "\n${BLUE}Service Status:${NC}"
docker-compose ps

# Health checks
echo -e "\n${BLUE}Performing health checks...${NC}"
if curl -sf http://localhost/health > /dev/null 2>&1; then
    echo -e "${GREEN}✓ Application is healthy${NC}"
else
    echo -e "${YELLOW}⚠ Application health check failed${NC}"
fi

# Setup cron job for automatic updates
echo -e "\n${BLUE}Step 12: Setting up automatic updates...${NC}"
CRON_JOB="0 2 * * * cd /home/ubuntu/dd-app && git pull origin main && docker-compose pull && docker-compose down && docker-compose up -d >> /home/ubuntu/dd-app/cron.log 2>&1"

(crontab -l 2>/dev/null | grep -v "dd-app" || true; echo "$CRON_JOB") | crontab -
echo -e "${GREEN}✓ Cron job configured (runs daily at 2 AM)${NC}"

# Setup logrotate
echo -e "\n${BLUE}Step 13: Setting up log rotation...${NC}"
sudo bash -c 'cat > /etc/logrotate.d/dd-app' << 'EOF'
/home/ubuntu/dd-app/cron.log {
    daily
    rotate 7
    compress
    delaycompress
    missingok
    notifempty
}
EOF
echo -e "${GREEN}✓ Log rotation configured${NC}"

echo -e "\n${GREEN}=========================================="
echo "Deployment Complete!"
echo "==========================================${NC}"

echo -e "\n${GREEN}Application is running at:${NC}"
echo "  Frontend:  http://$(curl -s https://checkip.amazonaws.com)"
echo "  Backend:   http://$(curl -s https://checkip.amazonaws.com):8080"

echo -e "\n${BLUE}Next Steps:${NC}"
echo "  1. Access your application in a web browser"
echo "  2. Configure GitHub Actions secrets for CI/CD"
echo "  3. Monitor logs: docker-compose logs -f"
echo "  4. Check status: docker-compose ps"

echo -e "\n${YELLOW}Useful Commands:${NC}"
echo "  SSH to VM:        ssh -i key.pem ubuntu@<VM_IP>"
echo "  View logs:        docker-compose logs -f"
echo "  Stop services:    docker-compose down"
echo "  Restart services: docker-compose restart"
echo "  View status:      docker-compose ps"
echo "  Update app:       git pull && docker-compose pull && docker-compose up -d"

echo -e "\n${YELLOW}Configuration Files:${NC}"
echo "  Docker Compose:   /home/ubuntu/dd-app/docker-compose.yml"
echo "  Nginx Config:     /home/ubuntu/dd-app/nginx.conf"
echo "  Backend Config:   /home/ubuntu/dd-app/backend/app/config/db.config.js"
echo "  Cron Log:         /home/ubuntu/dd-app/cron.log"

echo -e "\n${YELLOW}Important:${NC}"
echo "  - Make sure port 80 is open in your VM's security group"
echo "  - The application auto-updates daily at 2 AM UTC"
echo "  - Check cron.log for any deployment issues"
