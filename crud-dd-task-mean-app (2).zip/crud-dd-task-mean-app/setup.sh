#!/bin/bash

# MEAN Stack CRUD Application - Quick Setup Script

set -e

echo "=========================================="
echo "MEAN Stack CRUD App - Setup Script"
echo "=========================================="

# Colors for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check if Docker is installed
if ! command -v docker &> /dev/null; then
    echo -e "${YELLOW}Docker is not installed. Please install Docker first.${NC}"
    echo "Visit: https://docs.docker.com/get-docker/"
    exit 1
fi

# Check if Docker Compose is installed
if ! command -v docker-compose &> /dev/null; then
    echo -e "${YELLOW}Docker Compose is not installed. Please install Docker Compose first.${NC}"
    echo "Visit: https://docs.docker.com/compose/install/"
    exit 1
fi

echo -e "${GREEN}✓ Docker and Docker Compose are installed${NC}"

# Build images
echo -e "\n${BLUE}Building Docker images...${NC}"
docker-compose build

echo -e "${GREEN}✓ Images built successfully${NC}"

# Start services
echo -e "\n${BLUE}Starting services...${NC}"
docker-compose up -d

echo -e "${GREEN}✓ Services started${NC}"

# Wait for services to be ready
echo -e "\n${BLUE}Waiting for services to be healthy...${NC}"
sleep 10

# Check status
echo -e "\n${BLUE}Service Status:${NC}"
docker-compose ps

# Health checks
echo -e "\n${BLUE}Performing health checks...${NC}"

# Check MongoDB
if docker-compose exec -T mongodb mongosh --eval "db.runCommand('ping')" &> /dev/null; then
    echo -e "${GREEN}✓ MongoDB is healthy${NC}"
else
    echo -e "${YELLOW}⚠ MongoDB is not responding${NC}"
fi

# Check Backend
if curl -sf http://localhost:8080/ > /dev/null 2>&1; then
    echo -e "${GREEN}✓ Backend is healthy${NC}"
else
    echo -e "${YELLOW}⚠ Backend is not responding${NC}"
fi

# Check Frontend
if curl -sf http://localhost/health > /dev/null 2>&1; then
    echo -e "${GREEN}✓ Frontend is healthy${NC}"
else
    echo -e "${YELLOW}⚠ Frontend is not responding${NC}"
fi

echo -e "\n${BLUE}=========================================="
echo "Setup Complete!"
echo "==========================================${NC}"

echo -e "\n${GREEN}Application is ready at:${NC}"
echo "  Frontend:  http://localhost"
echo "  Backend:   http://localhost:8080"
echo "  MongoDB:   localhost:27017"

echo -e "\n${BLUE}Useful Commands:${NC}"
echo "  View logs:        docker-compose logs -f"
echo "  Stop services:    docker-compose down"
echo "  Restart services: docker-compose restart"
echo "  View status:      docker-compose ps"

echo -e "\n${YELLOW}Next Steps:${NC}"
echo "  1. Open http://localhost in your browser"
echo "  2. Test the application by adding a tutorial"
echo "  3. Check logs if you encounter any issues"
echo "  4. Refer to DEPLOYMENT_GUIDE.md for detailed instructions"
