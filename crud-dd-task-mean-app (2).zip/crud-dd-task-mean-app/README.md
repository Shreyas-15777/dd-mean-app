# MEAN Stack CRUD Application - DevOps Deployment

Complete containerization and deployment solution for a MEAN (MongoDB, Express, Angular, Node.js) stack CRUD application.

## Project Overview

This project demonstrates a production-ready MEAN stack application with complete DevOps setup including Docker containerization, orchestration, CI/CD automation, and cloud deployment.

**Live Application**: [Your VM IP will go here after deployment]

## Repository Contents

### 1. Dockerfiles and Container Configuration

#### Backend Dockerfile
```
backend/Dockerfile
```
- Multi-stage Node.js 18 Alpine build
- Production-optimized image
- Non-root user execution
- Health check configuration
- Minimal image size (~150MB)

#### Frontend Dockerfile
```
frontend/Dockerfile
```
- Node.js build stage + Nginx runtime
- Angular 15 application
- Optimized static asset serving
- Gzip compression enabled
- Final image size (~50MB)

#### Docker Compose Orchestration
```
docker-compose.yml
```
- 4 services: MongoDB, Backend, Frontend, Nginx
- Service health checks
- Network isolation
- Volume persistence for database
- Service dependencies

**Key Features:**
- Automatic service restart on failure
- Environment-based configuration
- Named volumes for data persistence
- Internal network communication

### 2. Nginx Configuration

#### Reverse Proxy Configuration
```
nginx.conf
```
- Main entry point at port 80
- API routing: `/api/*` → backend (8080)
- Static assets: `/` → frontend (3000)
- CORS headers configured
- Security headers included
- Gzip compression enabled

#### Frontend Nginx Configuration
```
frontend/nginx.conf
```
- Angular SPA routing (try_files)
- Static asset caching (30 days)
- Health check endpoint
- Error handling

### 3. CI/CD Pipeline Configuration

#### GitHub Actions Workflow
```
.github/workflows/deploy.yml
```

**Pipeline Stages:**
1. **Build Stage**
   - Docker image build for backend and frontend
   - Layer caching for optimization
   - Parallel builds for both services

2. **Push Stage**
   - Docker Hub image push
   - Image tagging (latest + commit SHA)
   - BuildKit cache management

3. **Test Stage** (on pull requests)
   - Docker Compose service startup
   - Health check verification
   - API endpoint testing

4. **Deploy Stage** (on main branch)
   - SSH connection to VM
   - Docker image pull
   - Container restart
   - Health verification

**Secrets Required:**
- `DOCKER_HUB_USERNAME` - Docker Hub account
- `DOCKER_HUB_TOKEN` - Docker Hub access token
- `VM_HOST` - VM IP address
- `VM_USER` - SSH username
- `VM_PRIVATE_KEY` - SSH private key
- `SLACK_WEBHOOK` (optional) - Slack notifications

### 4. Deployment Scripts

#### Local Setup Script
```
setup.sh
```
One-command local environment setup:
- Docker/Compose verification
- Image building
- Service startup
- Health checks
- Helpful output

#### VM Deployment Script
```
deploy-vm.sh
```
One-command Ubuntu VM setup:
- Docker installation
- Docker Compose installation
- Repository cloning
- Service deployment
- Automatic daily updates via cron
- Log rotation configuration

### 5. Project Structure

```
crud-dd-task-mean-app/
├── backend/
│   ├── Dockerfile
│   ├── .dockerignore
│   ├── app/
│   │   ├── config/
│   │   │   └── db.config.js (MongoDB connection)
│   │   ├── controllers/
│   │   ├── models/
│   │   └── routes/
│   ├── package.json
│   └── server.js
│
├── frontend/
│   ├── Dockerfile
│   ├── .dockerignore
│   ├── nginx.conf
│   ├── src/
│   │   ├── app/
│   │   │   ├── services/
│   │   │   ├── components/
│   │   │   └── app.module.ts
│   │   └── environments/
│   ├── package.json
│   └── angular.json
│
├── .github/
│   └── workflows/
│       └── deploy.yml
│
├── docker-compose.yml
├── nginx.conf (reverse proxy)
├── setup.sh
├── deploy-vm.sh
├── .gitignore
│
└── Documentation/
    ├── DEPLOYMENT_GUIDE.md
    ├── QUICK_REFERENCE.md
    └── IMPLEMENTATION_SUMMARY.md
```

## Setup and Deployment Instructions

### Prerequisites

- Docker and Docker Compose (for local testing)
- GitHub account
- Docker Hub account
- Ubuntu 20.04 VM on AWS/Azure/DigitalOcean (for deployment)
- Git

### Step 1: Local Testing

Test the application locally before deploying:

```bash
# Clone the repository
git clone https://github.com/Shreyas-15777/dd-mean-app.git
cd dd-mean-app

# Run setup script
chmod +x setup.sh
./setup.sh
```

**Expected Output:**
- All services running (docker-compose ps)
- Application accessible at http://localhost
- Health checks passing

### Step 2: Docker Hub Setup

1. Create Docker Hub account at hub.docker.com
2. Create two repositories:
   - `dd-backend`
   - `dd-frontend`
3. Generate access token (Account Settings → Security)
4. Document credentials securely

### Step 3: Cloud VM Setup

Create Ubuntu 20.04 LTS VM on your cloud provider:

**AWS EC2:**
- Instance Type: t2.medium
- Storage: 30GB
- Security Group: Allow ports 22, 80, 443

**Azure:**
- VM Size: Standard_B2s
- Image: Ubuntu Server 20.04 LTS
- Inbound Rules: Allow 22, 80, 443

**DigitalOcean:**
- Droplet Type: Basic
- Size: 4GB RAM, 2vCPU
- Region: Your choice

### Step 4: Deploy to VM

SSH into your VM and run:

```bash
ssh ubuntu@YOUR_VM_IP

curl -O https://raw.githubusercontent.com/Shreyas-15777/dd-mean-app/main/deploy-vm.sh
chmod +x deploy-vm.sh
./deploy-vm.sh
```

The script will:
- Install Docker and Docker Compose
- Clone your repository
- Build and start all services
- Configure automatic daily updates
- Set up log rotation

**Your application will be live at:** http://YOUR_VM_IP

### Step 5: CI/CD Configuration

1. Go to GitHub repository → Settings → Secrets and variables → Actions
2. Add required secrets:
   - DOCKER_HUB_USERNAME
   - DOCKER_HUB_TOKEN
   - VM_HOST
   - VM_USER
   - VM_PRIVATE_KEY

3. Generate SSH key for GitHub Actions:
```bash
ssh-keygen -t rsa -b 4096 -f gh-actions-key -N ""
cat gh-actions-key.pub | ssh ubuntu@VM_IP "cat >> ~/.ssh/authorized_keys"
```

4. Copy private key to GitHub secret (paste entire key content)

5. Test by pushing code to main branch:
```bash
git add .
git commit -m "Test CI/CD deployment"
git push origin main
```

Monitor deployment at: GitHub repo → Actions tab

## Application Features

The CRUD application allows users to:
- **Create** tutorials with title and description
- **Read** existing tutorials in a list
- **Update** tutorial details and publish status
- **Delete** tutorials
- **Search** tutorials by title
- **Filter** by published status

## Architecture

### Service Architecture

```
┌─────────────────────────────────────┐
│   Client Browser (Port 80)          │
│   Nginx Reverse Proxy               │
└──────────────┬──────────────────────┘
        ┌──────┴──────┐
        │             │
   [/api/* ]    [/* routes]
        │             │
    ┌───▼──┐      ┌────▼───┐
    │Backend│      │Frontend │
    │:8080  │      │:3000    │
    └───┬──┘      └────┬───┘
        │              │
        └──────┬───────┘
               │
        ┌──────▼──────┐
        │  MongoDB    │
        │  :27017     │
        └─────────────┘
```

### Service Details

| Service | Port | Type | Technology |
|---------|------|------|------------|
| MongoDB | 27017 | Database | MongoDB 6 Alpine |
| Backend | 8080 | API | Node.js 18 + Express |
| Frontend | 3000 | Web UI | Angular 15 + Nginx |
| Nginx | 80 | Reverse Proxy | Nginx Alpine |

### Network

- Services communicate on internal Docker network: `mean-network`
- Only Nginx (port 80) is exposed to public
- All service-to-service communication is internal

### Data Persistence

- MongoDB data stored in named volume: `mongodb_data`
- Volumes persist even after container restart
- Backup via `docker exec dd-mongodb mongodump`

## Configuration Files

### Environment Configuration

MongoDB Connection (backend/app/config/db.config.js):
```javascript
module.exports = {
  url: "mongodb://mongodb:27017/dd_db"
};
```

For MongoDB Atlas:
```javascript
module.exports = {
  url: "mongodb+srv://username:password@cluster.mongodb.net/dd_db"
};
```

### Docker Compose Configuration

Key environment variables in docker-compose.yml:
```yaml
NODE_ENV: production
PORT: 8080
MONGODB_URL: mongodb://mongodb:27017/dd_db
```

## Monitoring and Management

### View Service Status
```bash
docker-compose ps
```

### View Logs
```bash
# All services
docker-compose logs -f

# Specific service
docker-compose logs -f backend
docker-compose logs -f frontend
docker-compose logs -f mongodb
```

### Restart Services
```bash
docker-compose restart
docker-compose restart backend
```

### Stop Services
```bash
docker-compose down          # Keep volumes
docker-compose down -v       # Remove volumes
```

### Database Backup
```bash
docker exec dd-mongodb mongodump --out=/data/backup/
docker cp dd-mongodb:/data/backup ./backup
```

### Database Restore
```bash
docker cp ./backup dd-mongodb:/data/
docker exec dd-mongodb mongorestore /data/backup
```

## Troubleshooting

### Services Won't Start
```bash
# Check logs
docker-compose logs

# Verify Docker is running
docker ps

# Rebuild images
docker-compose build
docker-compose up -d
```

### Can't Access Application
```bash
# Verify services are running
docker-compose ps

# Test backend directly
curl http://localhost:8080/

# Check network
docker network inspect mean-network
```

### Database Connection Error
```bash
# Restart MongoDB
docker-compose restart mongodb

# Wait and restart backend
sleep 10
docker-compose restart backend

# Check logs
docker-compose logs mongodb
```

### CI/CD Deployment Failed
1. Check GitHub Actions → Actions tab
2. Review error logs in workflow run
3. Verify GitHub secrets are correct
4. Ensure SSH key is added to VM
5. Check VM firewall/security groups

### High Memory/CPU Usage
```bash
# Check resource usage
docker stats

# View container details
docker inspect dd-backend

# Limit resources in docker-compose.yml
# Add under service:
#   deploy:
#     resources:
#       limits:
#         memory: 512M
```

## CI/CD Pipeline Details

### Workflow Trigger

The GitHub Actions workflow is triggered by:
- Push to `main` branch → Full deployment
- Push to `develop` branch → Build and test only
- Pull requests → Test stage only

### Build Process

1. **Docker Build**
   - Multi-stage build for both frontend and backend
   - Layer caching for faster builds
   - Parallel execution for both services

2. **Image Push**
   - Authenticated push to Docker Hub
   - Tags: `latest` and commit SHA
   - BuildKit cache preservation

3. **Deployment**
   - SSH to VM
   - Pull latest images
   - Stop old containers
   - Start new containers
   - Health verification

### Health Checks

All services have health checks:
- **MongoDB**: mongosh ping command
- **Backend**: HTTP GET to /
- **Frontend**: wget to /health
- **Nginx**: wget to /health

Checks run every 10 seconds with 5-second timeouts.

## Security Features

### Container Security
- Non-root user execution
- Read-only root filesystem (where possible)
- Resource limits

### Network Security
- Internal Docker network isolation
- Only Nginx exposed publicly
- Service-to-service via internal DNS

### Access Control
- SSH key-based authentication (no passwords)
- GitHub Actions secrets management
- Environment variable separation

### Data Security
- MongoDB credentials in environment variables
- No sensitive data in source code
- Database backups available

### Application Security
- CORS headers configured
- Security headers in Nginx
- Input validation in API
- XSS protection headers

## Performance Optimization

### Image Size
- Alpine Linux base images (5-40MB)
- Multi-stage builds
- Only production dependencies

### Caching
- Docker layer caching
- Nginx gzip compression
- Static asset browser caching (30 days)

### Network
- Connection pooling in Nginx
- Keep-alive connections
- Efficient routing

### Database
- Indexed collections
- Query optimization
- Connection limits

## Scaling Considerations

### Horizontal Scaling
- Multiple backend instances behind Nginx
- Load balancing configuration available
- Stateless application design

### Vertical Scaling
- Resource limits configurable in docker-compose.yml
- Database optimization options
- VM size upgrades

### Monitoring
- Log aggregation ready
- Metrics collection available
- Performance monitoring tools

## Production Checklist

Before going live:

- [ ] Local testing completed
- [ ] All tests passing
- [ ] CI/CD workflow successful
- [ ] VM deployment verified
- [ ] Application accessible
- [ ] Database persistence working
- [ ] Backups configured
- [ ] Monitoring in place
- [ ] Security review completed
- [ ] Documentation reviewed
- [ ] Team trained
- [ ] Runbooks created

## Additional Resources

- [Docker Documentation](https://docs.docker.com/)
- [Docker Compose Documentation](https://docs.docker.com/compose/)
- [GitHub Actions Documentation](https://docs.github.com/en/actions)
- [Nginx Documentation](https://nginx.org/en/docs/)
- [MongoDB Documentation](https://docs.mongodb.com/)
- [Angular Documentation](https://angular.io/docs)

## Support

For issues or questions:

1. Check logs: `docker-compose logs`
2. Review QUICK_REFERENCE.md for common solutions
3. Check DEPLOYMENT_GUIDE.md for detailed instructions
4. Review GitHub Actions workflow logs
5. Verify all prerequisites are met

## License

This project includes the original MEAN stack CRUD application with DevOps enhancements for containerization and deployment.

## Contributing

To contribute:

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test locally with `./setup.sh`
5. Push to your fork
6. Create a pull request

## Version

- Version: 1.0
- Last Updated: February 24, 2026
- Status: Production Ready

---

**Ready to deploy?** Follow the Setup and Deployment Instructions above to get started!
